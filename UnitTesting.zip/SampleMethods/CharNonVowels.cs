﻿namespace BasicMethods
{
    public class CharNonVowels
    {
        public static int GetNumberOfNonVowels(char[] symbols)
        {
            int nonVowelsCount = 0;
            List<int> vowelsAsciiIndexes = new List<int> { 65, 69, 73, 79, 85, 97, 101, 105, 111, 117 };

            foreach (char ch in symbols)
            {
                if (!vowelsAsciiIndexes.Contains(ch))
                {
                    nonVowelsCount++;
                }
            }

            return nonVowelsCount;
        }
    }
}
