﻿namespace BasicMethods
{
    public class PositiveArrayExtractor
    {
        public static int GetPositiveEvenSum(int[] array)
        {
            int sum = 0;
            int current;
            int digitSum = 0;
            int digit;

            for (int i = 0; i < array.Length; i++)
            {
                current = array[i];
                if (current % 2 == 0)
                {
                    while (current != 0)
                    {
                        digit = current % 10;
                        digitSum += digit;
                        current /= 10;
                    }

                    sum = digitSum + sum;
                    digitSum = 0;
                }
            }

            return sum;
        }
    }
}

