﻿namespace BasicMethods.UnitTests
{
    public class PositiveArrayExtractorTests
    {
        [Test, Order(1)]
        public void Test_GetPositiveEvenSum_EmptyArray()
        {
            //Arrange
            int[] array = new int[] { };

            //Act
            int result = PositiveArrayExtractor.GetPositiveEvenSum(array);

            //Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(2)]
        public void Test_GetPositiveEvenSum_SingleEvenElementArray()
        {
            //Arrange
            int[] array = new int[] { 2 };

            //Act
            int result = PositiveArrayExtractor.GetPositiveEvenSum(array);

            //Assert
            Assert.That(result, Is.EqualTo(2));
        }

        [Test, Order(3)]
        public void Test_GetPositiveEvenSum_SingleOddElementArray()
        {
            //Arrange
            int[] array = new int[] { 5 };

            //Act
            int result = PositiveArrayExtractor.GetPositiveEvenSum(array);

            //Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(4)]
        public void Test_GetPositiveEvenSum_MultipleEvenElementArray()
        {
            //Arrange
            int[] array = new int[] { 2, 4, 22, 88, 104, 1044, 45882 };

            //Act
            int result = PositiveArrayExtractor.GetPositiveEvenSum(array);

            //Assert
            Assert.That(result, Is.EqualTo(67));
        }

        [Test, Order(5)]
        public void Test_GetPositiveEvenSum_MultipleEvenElementWithZeroArray()
        {
            //Arrange
            int[] array = new int[] { 2, 4, 22, 88, 104, 0, 1044, 45882 };

            //Act
            int result = PositiveArrayExtractor.GetPositiveEvenSum(array);

            //Assert
            Assert.That(result, Is.EqualTo(67));
        }

        [Test, Order(6)]
        public void Test_GetPositiveEvenSum_MultipleOddElementArray()
        {
            //Arrange
            int[] array = new int[] { 3, 11, 333, 1111, 12337 };

            //Act
            int result = PositiveArrayExtractor.GetPositiveEvenSum(array);

            //Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(7)]
        public void Test_GetPositiveEvenSum_MultipleOddElementWithZeroArray()
        {
            //Arrange
            int[] array = new int[] { 3, 11, 333, 1111, 12337, 0 };

            //Act
            int result = PositiveArrayExtractor.GetPositiveEvenSum(array);

            //Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(8)]
        public void Test_GetPositiveEvenSum_ElementZeroArray()
        {
            //Arrange
            int[] array = new int[] { 0 };

            //Act
            int result = PositiveArrayExtractor.GetPositiveEvenSum(array);

            //Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(9)]
        public void Test_GetPositiveEvenSum_MultipleElementZeroArray()
        {
            //Arrange
            int[] array = new int[] { 0, 0, 0, 0, 0, 0, 0, 0 };

            //Act
            int result = PositiveArrayExtractor.GetPositiveEvenSum(array);

            //Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(9)]
        public void Test_GetPositiveEvenSum_MixedElementArray()
        {
            //Arrange
            int[] array = new int[] { 7, 18, 21, 333, 4842, 11301 };

            //Act
            int result = PositiveArrayExtractor.GetPositiveEvenSum(array);

            //Assert
            Assert.That(result, Is.EqualTo(27));
        }

        [Test, Order(9)]
        public void Test_GetPositiveEvenSum_MixedElementWithZeroArray()
        {
            //Arrange
            int[] array = new int[] { 1, 13, 18, 228, 4382, 12363, 0 };

            //Act
            int result = PositiveArrayExtractor.GetPositiveEvenSum(array);

            //Assert
            Assert.That(result, Is.EqualTo(38));
        }
    }
}
