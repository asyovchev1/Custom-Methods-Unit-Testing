﻿namespace BasicMethods
{
    public class CharVowels
    {
        public static int GetNumberOfVowels(char[] symbols)
        {
            int vowelsCount = 0;
            List<int> vowelsAsciiIndexes = new List<int> { 65, 69, 73, 79, 85, 97, 101, 105, 111, 117 };

            foreach (char ch in symbols)
            {
                if (vowelsAsciiIndexes.Contains(ch))
                {
                    vowelsCount++;
                }
            }

            return vowelsCount;
        }
    }
}
