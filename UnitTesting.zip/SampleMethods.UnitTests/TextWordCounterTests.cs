﻿namespace BasicMethods.UnitTests
{
    public class TextWordCounterTests
    {
        [Test, Order(1)]
        public void Test_CountWordInText_BothEmptyStrings()
        {
            //Arrange
            string text = "";
            string seekedWord = "";

            //Act
            int result = TextWordCounter.CountWordInText(text, seekedWord);

            //Assert
            Assert.That(result, Is.EqualTo(1));
        }

        [Test, Order(2)]
        public void Test_CountWordInText_FirstEmptyString()
        {
            //Arrange
            string text = "";
            string seekedWord = "apple";

            //Act
            int result = TextWordCounter.CountWordInText(text, seekedWord);

            //Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(3)]
        public void Test_CountWordInText_SecondEmptyString()
        {
            //Arrange
            string text = "The white rabbit jumped into the hole.";
            string seekedWord = "";

            //Act
            int result = TextWordCounter.CountWordInText(text, seekedWord);

            //Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(4)]
        public void Test_CountWordInText_NoMatchingSeekedWord()
        {
            //Arrange
            string text = "Jupiter is the largest planet in the Solar System.";
            string seekedWord = "Venus";

            //Act
            int result = TextWordCounter.CountWordInText(text, seekedWord);

            //Assert
            Assert.That(result, Is.EqualTo(0));
        }

        [Test, Order(5)]
        public void Test_CountWordInText_MatchingSeekedWord()
        {
            //Arrange
            string text = "Jupiter is the largest planet in the Solar System.";
            string seekedWord = "Jupiter";

            //Act
            int result = TextWordCounter.CountWordInText(text, seekedWord);

            //Assert
            Assert.That(result, Is.EqualTo(1));
        }

        [Test, Order(6)]
        public void Test_CountWordInText_MultipleMatchingSeekedWord()
        {
            //Arrange
            string text = "Jupiter is the largest planet in the Jupiter System.";
            string seekedWord = "Jupiter";

            //Act
            int result = TextWordCounter.CountWordInText(text, seekedWord);

            //Assert
            Assert.That(result, Is.EqualTo(2));
        }
    }
}