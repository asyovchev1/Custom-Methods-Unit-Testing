﻿using System.Text;

namespace BasicMethods
{
    public class StringLettersToUpper
    {
        public static string CapitalizeSomeStringLetters(string input)
        {
            StringBuilder output = new StringBuilder();
            char a;
            foreach (char c in input)
            {
                if (c >= 97 && c <= 109)
                {
                    a = Convert.ToChar((c - 32));
                    output.Append(a);
                }
                else
                {
                    output.Append(c);
                }
            }

            return output.ToString();
        }
    }
}

