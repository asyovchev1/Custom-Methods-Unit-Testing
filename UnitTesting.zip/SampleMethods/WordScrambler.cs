﻿namespace BasicMethods
{
    public class WordScrambler
    {
        public static List<string> ScrambleWords(List<string> input)
        {
            string currentWord;
            char[] letters;
            char letter;

            List<string> words = input;
            for (int i = 0; i < words.Count; i++)
            {
                currentWord = words[i];
                letters = currentWord.ToCharArray();
                for (int j = 0; j < letters.Length; j++)
                {
                    letter = (char)(Convert.ToUInt32(letters[j]) + 1);
                    letters[j] = letter;
                }

                currentWord = new string(letters);
                words[i] = currentWord;
            }

            return words;
        }
    }
}

