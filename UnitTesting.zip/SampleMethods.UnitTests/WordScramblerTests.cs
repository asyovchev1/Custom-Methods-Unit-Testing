﻿namespace BasicMethods.UnitTests
{
    public class WorldScramblerTests
    {
        [Test, Order(1)]
        public void Test_ScrambleWords_EmptyList()
        {
            //Arrange
            List<string> input = new List<string> { };
            List<string> output = new List<string> { };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(2)]
        public void Test_ScrambleWords_EmptyString()
        {
            //Arrange
            List<string> input = new List<string> { "" };
            List<string> output = new List<string> { "" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(3)]
        public void Test_ScrambleWords_MultipleEmptyStrings()
        {
            //Arrange
            List<string> input = new List<string> { "", "", "" };
            List<string> output = new List<string> { "", "", "" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(4)]
        public void Test_ScrambleWords_SingleLetterString()
        {
            //Arrange
            List<string> input = new List<string> { "a" };
            List<string> output = new List<string> { "b" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(5)]
        public void Test_ScrambleWords_SingleLetterStringEmptyString()
        {
            //Arrange
            List<string> input = new List<string> { "d", "" };
            List<string> output = new List<string> { "e", "" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(6)]
        public void Test_ScrambleWords_SingleLetterStringEmptyStrings()
        {
            //Arrange
            List<string> input = new List<string> { "d", "", "" };
            List<string> output = new List<string> { "e", "", "" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(7)]
        public void Test_ScrambleWords_SingleString()
        {
            //Arrange
            List<string> input = new List<string> { "apple" };
            List<string> output = new List<string> { "bqqmf" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(8)]
        public void Test_ScrambleWords_SingleStringEmptyString()
        {
            //Arrange
            List<string> input = new List<string> { "banana", "" };
            List<string> output = new List<string> { "cbobob", "" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(9)]
        public void Test_ScrambleWords_SingleStringEmptyStrings()
        {
            //Arrange
            List<string> input = new List<string> { "banana", "", "" };
            List<string> output = new List<string> { "cbobob", "", "" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(10)]
        public void Test_ScrambleWords_TwoStrings()
        {
            //Arrange
            List<string> input = new List<string> { "pear", "lemon" };
            List<string> output = new List<string> { "qfbs", "mfnpo" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(11)]
        public void Test_ScrambleWords_TwoStringsEmptyString()
        {
            //Arrange
            List<string> input = new List<string> { "orange", "strawberry", "" };
            List<string> output = new List<string> { "psbohf", "tusbxcfssz", "" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(12)]
        public void Test_ScrambleWords_TwoStringsEmptyStrings()
        {
            //Arrange
            List<string> input = new List<string> { "kiwi", "melon", "", "" };
            List<string> output = new List<string> { "ljxj", "nfmpo", "", "" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(13)]
        public void Test_ScrambleWords_MultipleStrings()
        {
            //Arrange
            List<string> input = new List<string> { "pumpkin", "watermelon", "raspberry" };
            List<string> output = new List<string> { "qvnqljo", "xbufsnfmpo", "sbtqcfssz" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(14)]
        public void Test_ScrambleWords_MultipleStringsBlanks()
        {
            //Arrange
            List<string> input = new List<string> { "pumpkin", "water melon", "rasp berry" };
            List<string> output = new List<string> { "qvnqljo", "xbufs!nfmpo", "sbtq!cfssz" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(15)]
        public void Test_ScrambleWords_SingleCapitalLetterString()
        {
            //Arrange
            List<string> input = new List<string> { "T" };
            List<string> output = new List<string> { "U" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(16)]
        public void Test_ScrambleWords_SingleCapitalLetterStringEmptyString()
        {
            //Arrange
            List<string> input = new List<string> { "K", "" };
            List<string> output = new List<string> { "L", "" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(17)]
        public void Test_ScrambleWords_SingleCapitalLetterStringEmptyStrings()
        {
            //Arrange
            List<string> input = new List<string> { "F", "", "" };
            List<string> output = new List<string> { "G", "", "" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(18)]
        public void Test_ScrambleWords_SingleCapitalString()
        {
            //Arrange
            List<string> input = new List<string> { "YELLOW" };
            List<string> output = new List<string> { "ZFMMPX" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(19)]
        public void Test_ScrambleWords_SingleCapitalStringEmptyString()
        {
            //Arrange
            List<string> input = new List<string> { "CABBAGE", "" };
            List<string> output = new List<string> { "DBCCBHF", "" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(20)]
        public void Test_ScrambleWords_SingleCapitalStringEmptyStrings()
        {
            //Arrange
            List<string> input = new List<string> { "GREEN", "", "" };
            List<string> output = new List<string> { "HSFFO", "", "" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(21)]
        public void Test_ScrambleWords_TwoCapitalStrings()
        {
            //Arrange
            List<string> input = new List<string> { "NOVEMBER", "DECEMBER" };
            List<string> output = new List<string> { "OPWFNCFS", "EFDFNCFS" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(22)]
        public void Test_ScrambleWords_TwoCapitalStringsEmptyString()
        {
            //Arrange
            List<string> input = new List<string> { "DILIGENCE", "IMPORTANT", "" };
            List<string> output = new List<string> { "EJMJHFODF", "JNQPSUBOU", "" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(23)]
        public void Test_ScrambleWords_TwoCapitalStringsEmptyStrings()
        {
            //Arrange
            List<string> input = new List<string> { "EUROPE", "AFRICA", "", "" };
            List<string> output = new List<string> { "FVSPQF", "BGSJDB", "", "" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(24)]
        public void Test_ScrambleWords_MultipleStringsCapitalLetters()
        {
            //Arrange
            List<string> input = new List<string> { "PUMPKIN", "WATERMELON", "RASPBERRY" };
            List<string> output = new List<string> { "QVNQLJO", "XBUFSNFMPO", "SBTQCFSSZ" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(25)]
        public void Test_ScrambleWords_MultipleStringsCapitalLettersBlanks()
        {
            //Arrange
            List<string> input = new List<string> { "PUMP KIN", "WATERMELON", "RASPBE RRY" };
            List<string> output = new List<string> { "QVNQ!LJO", "XBUFSNFMPO", "SBTQCF!SSZ" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(26)]
        public void Test_ScrambleWords_SingleStringSpecialSymbols()
        {
            //Arrange
            List<string> input = new List<string> { "%(&_!^$" };
            List<string> output = new List<string> { "&)'`\"_%" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(27)]
        public void Test_ScrambleWords_MultipleStringsSpecialSymbols()
        {
            //Arrange
            List<string> input = new List<string> { "%(&_!^$", "$!&#^+=@>" };
            List<string> output = new List<string> { "&)'`\"_%", "%\"'$_,>A?" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(28)]
        public void Test_ScrambleWords_MultipleStringsSpecialSymbolsEmptyString()
        {
            //Arrange
            List<string> input = new List<string> { "*****", "%%%%", "" };
            List<string> output = new List<string> { "+++++", "&&&&", "" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(29)]
        public void Test_ScrambleWords_SingleDigitString()
        {
            //Arrange
            List<string> input = new List<string> { "8" };
            List<string> output = new List<string> { "9" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(30)]
        public void Test_ScrambleWords_SingleDigitStrings()
        {
            //Arrange
            List<string> input = new List<string> { "8", "0" };
            List<string> output = new List<string> { "9", "1" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(31)]
        public void Test_ScrambleWords_MultipleDigitString()
        {
            //Arrange
            List<string> input = new List<string> { "23548" };
            List<string> output = new List<string> { "34659" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(32)]
        public void Test_ScrambleWords_MultipleDigitStrings()
        {
            //Arrange
            List<string> input = new List<string> { "23548", "124236" };
            List<string> output = new List<string> { "34659", "235347" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(32)]
        public void Test_ScrambleWords_MultipleDigitStringsEmptyString()
        {
            //Arrange
            List<string> input = new List<string> { "23548", "124236", "" };
            List<string> output = new List<string> { "34659", "235347", "" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }

        [Test, Order(33)]
        public void Test_ScrambleWords_MultipleDigitStringsEmptyStrings()
        {
            //Arrange
            List<string> input = new List<string> { "23548", "124236", "", "" };
            List<string> output = new List<string> { "34659", "235347", "", "" };

            //Act
            input = WordScrambler.ScrambleWords(input);

            //Assert
            Assert.That(input, Is.EqualTo(output));
        }
    }
}