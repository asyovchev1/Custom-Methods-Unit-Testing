﻿namespace BasicMethods
{
    public class TextWordCounter
    {
        public static int CountWordInText(string text, string seekedWord)
        {
            int wordCounter = 0;
            string[] words = text.Split(' ');
            for (int i = 0; i < words.Length; i++)
            {
                if (words[i] == seekedWord)
                {
                    wordCounter++;
                }
            }

            return wordCounter;
        }
    }
}

