﻿namespace BasicMethods.UnitTests
{
    public class CharNonVowelsTests
    {
        [Test, Order(1)]
        public void Test_GetNumberOfNonVowels_GetNumberOfLowerCaseNonVowels()
        {
            //Arrange
            char[] letters = new[] { 'r', 'f', 'm' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(3));
        }

        [Test, Order(2)]
        public void Test_GetNumberOfNonVowels_GetNumberOfUpperCaseNonVowels()
        {
            //Arrange
            char[] letters = new[] { 'H', 'M', 'D' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(3));
        }

        [Test, Order(3)]
        public void Test_GetNumberOfNonVowels_GetNumberMixedCaseNonVowels()
        {
            //Arrange
            char[] letters = new[] { 'g', 'Y', 'N', 'b' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(4));
        }

        [Test, Order(4)]
        public void Test_GetNumberOfNonVowels_GetNumberLowerCaseNoNonVowels()
        {
            //Arrange
            char[] letters = new[] { 'a', 'e', 'i', 'o' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(0));
        }

        [Test, Order(5)]
        public void Test_GetNumberOfNonVowels_GetNumberUpperCaseNoNonVowels()
        {
            //Arrange
            char[] letters = new[] { 'A', 'E', 'I', 'O', 'U' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(0));
        }

        [Test, Order(6)]
        public void Test_GetNumberOfNonVowels_GetNumberMixedCaseNoNonVowels()
        {
            //Arrange
            char[] letters = new[] { 'e', 'A', 'i', 'u', 'U', 'O' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(0));
        }

        [Test, Order(7)]
        public void Test_GetNumberOfNonVowels_MixedCaseVowelsNonVowels()
        {
            //Arrange
            char[] letters = new[] { 'f', 'a', 'E', 'I', 'E', 'j', 'H' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(3));
        }

        [Test, Order(8)]
        public void Test_GetNumberOfNonVowels_LowerCaseNonVowelsWithDigits()
        {
            //Arrange
            char[] letters = new[] { 'j', '7', 'p', '9', 'r', '8' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(6));
        }

        [Test, Order(9)]
        public void Test_GetNumberOfNonVowels_UpperCaseNonVowelsWithDigits()
        {
            //Arrange
            char[] letters = new[] { 'T', '4', '9', 'R', 'A', 'K' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(5));
        }

        [Test, Order(10)]
        public void Test_GetNumberOfNonVowels_MixedCaseNonVowelsWithDigits()
        {
            //Arrange
            char[] letters = new[] { 'B', '9', 'f', '1', 'l' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(5));
        }

        [Test, Order(11)]
        public void Test_GetNumberOfNonVowels_MixedCaseVowelsWithDigits()
        {
            //Arrange
            char[] letters = new[] { 'A', 'e', '4', '1', 'I' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(2));
        }

        [Test, Order(12)]
        public void Test_GetNumberOfNonVowels_MixedCaseVowelsNonVowelsWithDigits()
        {
            //Arrange
            char[] letters = new[] { 'K', '1', 'O', 't', '6', 'a', 'N' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(5));
        }

        [Test, Order(13)]
        public void Test_GetNumberOfNonVowels_LowerCaseNonVowelsWithSpecialSymbols()
        {
            //Arrange
            char[] letters = new[] { ')', 't', '!', '^', '"' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(5));
        }

        [Test, Order(14)]
        public void Test_GetNumberOfNonVowels_UpperCaseNonVowelsWithSpecialSymbols()
        {
            //Arrange
            char[] letters = new[] { '(', 'Y', '-', 'M', 'L', '$', ')' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(7));
        }

        [Test, Order(15)]
        public void Test_GetNumberOfNonVowels_MixedCaseVowelsNonVowelsWithSpecialSymbols()
        {
            //Arrange
            char[] letters = new[] { '@', 'a', '$', 'g', 'E', '^', 'R', 'u', '!' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(6));
        }

        [Test, Order(16)]
        public void Test_GetNumberOfNonVowels_OnlySpecialSymbols()
        {
            //Arrange
            char[] letters = new[] { '#', '~', '(', '%', '*' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(5));
        }

        [Test, Order(17)]
        public void Test_GetNumberOfNonVowels_SpecialSymbolsWithLowerCaseLetters()
        {
            //Arrange
            char[] letters = new[] { '-', 'a', '(', '%', 'f', '=', 'g' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(6));
        }

        [Test, Order(18)]
        public void Test_GetNumberOfNonVowels_SpecialSymbolsWithMixedCaseLetters()
        {
            //Arrange
            char[] letters = new[] { '#', 'a', '(', '%', 'T', 'i', 'z', 'E', '+' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(6));
        }

        [Test, Order(19)]
        public void Test_GetNumberOfNonVowels_SpecialSymbolsWithDigits()
        {
            //Arrange
            char[] letters = new[] { '#', '8', '(', '$', '6', ',', '9', '>', '+' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(9));
        }

        [Test, Order(20)]
        public void Test_GetNumberOfNonVowels_SpecialSymbolsWithAll()
        {
            //Arrange
            char[] letters = new[] { '#', 'a', ')', '%', '1', 'g', '&', 'E', '+', '8', 'T', '\'' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(10));
        }

        [Test, Order(21)]
        public void Test_GetNumberOfNonVowels_SingleNonVowel()
        {
            //Arrange
            char[] letters = new char[] { 'c' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(1));
        }

        [Test, Order(22)]
        public void Test_GetNumberOfNonVowels_SingleVowel()
        {
            //Arrange
            char[] letters = new char[] { 'a' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(0));
        }

        [Test, Order(23)]
        public void Test_GetNumberOfNonVowels_SingleDigit()
        {
            //Arrange
            char[] letters = new char[] { '6' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(1));
        }

        [Test, Order(24)]
        public void Test_GetNumberOfNonVowels_SingleSpecialSymbol()
        {
            //Arrange
            char[] letters = new char[] { '$' };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(1));
        }

        //Last test
        [Test, Order(25)]
        public void Test_GetNumberOfNonVowels_NoCharacters()
        {
            //Arrange
            char[] letters = new char[] { };

            //Act
            int output = CharNonVowels.GetNumberOfNonVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(0));
        }
    }
}

