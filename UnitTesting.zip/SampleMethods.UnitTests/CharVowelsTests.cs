﻿namespace BasicMethods.UnitTests
{
    public class CharVowelsTests
    {
        [Test, Order(1)]
        public void Test_GetNumberOfVowels_GetNumberOfLowerCaseVowels()
        {
            //Arrange
            char[] letters = new[] { 'e', 'a', 'u' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(3));
        }

        [Test, Order(2)]
        public void Test_GetNumberOfVowels_GetNumberOfUpperCaseVowels()
        {
            //Arrange
            char[] letters = new[] { 'O', 'I', 'E' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(3));
        }

        [Test, Order(3)]
        public void Test_GetNumberOfVowels_GetNumberMixedCaseVowels()
        {
            //Arrange
            char[] letters = new[] { 'e', 'A', 'o', 'U' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(4));
        }

        [Test, Order(4)]
        public void Test_GetNumberOfVowels_GetNumberLowerCaseNoVowels()
        {
            //Arrange
            char[] letters = new[] { 'b', 's', 'l', 'r' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(0));
        }

        [Test, Order(5)]
        public void Test_GetNumberOfVowels_GetNumberUpperCaseNoVowels()
        {
            //Arrange
            char[] letters = new[] { 'Y', 'W', 'Q', 'L', 'M' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(0));
        }

        [Test, Order(6)]
        public void Test_GetNumberOfVowels_GetNumberMixedCaseNoVowels()
        {
            //Arrange
            char[] letters = new[] { 'n', 'B', 'v', 'R', 'W', 'K' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(0));
        }

        [Test, Order(7)]
        public void Test_GetNumberOfVowels_MixedCaseVowelsNonVowels()
        {
            //Arrange
            char[] letters = new[] { 'a', 'K', 's', 'I', 'E', 'j', 'H' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(3));
        }

        [Test, Order(8)]
        public void Test_GetNumberOfVowels_LowerCaseVowelsWithDigits()
        {
            //Arrange
            char[] letters = new[] { 'a', '7', 'i', '9', '0', 'u' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(3));
        }

        [Test, Order(9)]
        public void Test_GetNumberOfVowels_UpperCaseVowelsWithDigits()
        {
            //Arrange
            char[] letters = new[] { 'E', '4', 'O', '6', 'A', 'I' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(4));
        }

        [Test, Order(10)]
        public void Test_GetNumberOfVowels_MixedCaseVowelsWithDigits()
        {
            //Arrange
            char[] letters = new[] { 'a', '9', 'A', '1', 'e' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(3));
        }

        [Test, Order(11)]
        public void Test_GetNumberOfVowels_MixedCaseNonVowelsWithDigits()
        {
            //Arrange
            char[] letters = new[] { 'T', '9', 'W', '1', 's' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(0));
        }

        [Test, Order(12)]
        public void Test_GetNumberOfVowels_MixedCaseVowelsNonVowelsWithDigits()
        {
            //Arrange
            char[] letters = new[] { 'a', '9', 'A', 't', '1', 'e', 'Z' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(3));
        }

        [Test, Order(13)]
        public void Test_GetNumberOfVowels_LowerCaseVowelsWithSpecialSymbols()
        {
            //Arrange
            char[] letters = new[] { '@', 'a', '!', 'e', '^', '"' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(2));
        }

        [Test, Order(14)]
        public void Test_GetNumberOfVowels_UpperCaseVowelsWithSpecialSymbols()
        {
            //Arrange
            char[] letters = new[] { '(', 'A', '-', 'I', 'E', '$', ')' };

            //Act
            int output =    CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(3));
        }

        [Test, Order(15)]
        public void Test_GetNumberOfVowels_MixedCaseVowelsNonVowelsWithSpecialSymbols()
        {
            //Arrange
            char[] letters = new[] { '@', 'a', '$', 'e', 'E', '^', 'R', 'u', '!' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(4));
        }

        [Test, Order(16)]
        public void Test_GetNumberOfVowels_OnlySpecialSymbols()
        {
            //Arrange
            char[] letters = new[] { '#', '~', '(', '%', '*' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(0));
        }

        [Test, Order(17)]
        public void Test_GetNumberOfVowels_SpecialSymbolsWithLowerCaseLetters()
        {
            //Arrange
            char[] letters = new[] { '-', 'a', '(', '%', 'f', '=', 'g' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(1));
        }

        [Test, Order(18)]
        public void Test_GetNumberOfVowels_SpecialSymbolsWithMixedCaseLetters()
        {
            //Arrange
            char[] letters = new[] { '#', 'a', '(', '%', 'T', 'i', 'z', 'E', '+' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(3));
        }

        [Test, Order(19)]
        public void Test_GetNumberOfVowels_SpecialSymbolsWithDigits()
        {
            //Arrange
            char[] letters = new[] { '#', '8', '(', '$', '6', ',', '9', '>', '+' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(0));
        }

        [Test, Order(20)]
        public void Test_GetNumberOfVowels_SpecialSymbolsWithAll()
        {
            //Arrange
            char[] letters = new[] { '#', 'a', ')', '%', '1', 'g', '&', 'E', '+', '8', 'T', '\'' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(2));
        }

        [Test, Order(21)]
        public void Test_GetNumberOfVowels_SingleNonVowel()
        {
            //Arrange
            char[] letters = new char[] { 'c' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(0));
        }

        [Test, Order(22)]
        public void Test_GetNumberOfVowels_SingleVowel()
        {
            //Arrange
            char[] letters = new char[] { 'a' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(1));
        }

        [Test, Order(23)]
        public void Test_GetNumberOfVowels_SingleDigit()
        {
            //Arrange
            char[] letters = new char[] { '6' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(0));
        }

        [Test, Order(24)]
        public void Test_GetNumberOfVowels_SingleSpecialSymbol()
        {
            //Arrange
            char[] letters = new char[] { '$' };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(0));
        }

        //Last test
        [Test, Order(25)]
        public void Test_GetNumberOfVowels_NoCharacters()
        {
            //Arrange
            char[] letters = new char[] { };

            //Act
            int output = CharVowels.GetNumberOfVowels(letters);

            //Assert
            Assert.That(output, Is.EqualTo(0));
        }
    }
}