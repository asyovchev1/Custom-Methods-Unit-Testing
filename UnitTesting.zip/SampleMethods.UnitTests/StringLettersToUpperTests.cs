﻿namespace BasicMethods.UnitTests
{
    public class StringLettersToUpperTests
    {
        [Test, Order(1)]
        public void Test_CapitalizeSomeStringLetters_AllLowerCaseLetters()
        {
            //Arrange
            string input = "apple";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo("AppLE"));
        }

        [Test, Order(2)]
        public void Test_CapitalizeSomeStringLetters_AllUpperCaseLetters()
        {
            //Arrange
            string input = "BANANA";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo("BANANA"));
        }

        [Test, Order(3)]
        public void Test_CapitalizeSomeStringLetters_MixedCaseLetters()
        {
            //Arrange
            string input = "sUbMaRiNE";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo("sUBMARINE"));
        }

        [Test, Order(4)]
        public void Test_CapitalizeSomeStringLetters_LowerCaseLettersWithDigits()
        {
            //Arrange
            string input = "a9Hk67bZd7f";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo("A9HK67BZD7F"));
        }

        [Test, Order(5)]
        public void Test_CapitalizeSomeStringLetters_UpperCaseLettersWithDigits()
        {
            //Arrange
            string input = "B7J8NL8W1I5T3";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo("B7J8NL8W1I5T3"));
        }

        [Test, Order(6)]
        public void Test_CapitalizeSomeStringLetters_MixedCaseLettersWithDigits()
        {
            //Arrange
            string input = "Aa8iJtK7b90e8";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo("AA8IJtK7B90E8"));
        }

        [Test, Order(7)]
        public void Test_CapitalizeSomeStringLetters_AllLowerCaseLettersWithSpecialSymbols()
        {
            //Arrange
            string input = "in%s&ti**t#u!t)i^o$n";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo("In%s&tI**t#u!t)I^o$n"));
        }

        [Test, Order(8)]
        public void Test_CapitalizeSomeStringLetters_AllUpperCaseLettersWithSpecialSymbols()
        {
            //Arrange
            string input = "D&EC*L^AR#A@TI)O(N";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo("D&EC*L^AR#A@TI)O(N"));
        }

        [Test, Order(9)]
        public void Test_CapitalizeSomeStringLetters_MixedCaseLettersWithSpecialSymbols()
        {
            //Arrange
            string input = "iN$d*ePe(N|De&Nc#e";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo("IN$D*EPE(N|DE&NC#E"));
        }

        [Test, Order(10)]
        public void Test_CapitalizeSomeStringLetters_MixedAllLetters()
        {
            //Arrange
            string input = "c(o9&NS^4t)i3T9uT!i0o$N";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo("C(o9&NS^4t)I3T9uT!I0o$N"));
        }

        [Test, Order(11)]
        public void Test_CapitalizeSomeStringLetters_AllLowerCaseLettersSentence()
        {
            //Arrange
            string input = "I like apples and lemons.";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo("I LIKE AppLEs AnD LEMons."));
        }

        [Test, Order(12)]
        public void Test_CapitalizeSomeStringLetters_AllUpperCaseLettersSentence()
        {
            //Arrange
            string input = "CHOCOLATE CAN MAKE YOU FAT.";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo("CHOCOLATE CAN MAKE YOU FAT."));
        }

        [Test, Order(13)]
        public void Test_CapitalizeSomeStringLetters_MixedCaseLettersSentence()
        {
            //Arrange
            string input = "ThE BlACk sEa is bIg.";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo("THE BLACK sEA Is BIG."));
        }

        [Test, Order(14)]
        public void Test_CapitalizeSomeStringLetters_LowerCaseLettersSentenceWithDigits()
        {
            //Arrange
            string input = "i have 3 nokia 3310 phones.";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo("I HAvE 3 noKIA 3310 pHonEs."));
        }

        [Test, Order(15)]
        public void Test_CapitalizeSomeStringLetters_UpperCaseLettersSentenceWithDigits()
        {
            //Arrange
            string input = "I A2M 5 LU8CKY.";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo("I A2M 5 LU8CKY."));
        }

        [Test, Order(16)]
        public void Test_CapitalizeSomeStringLetters_MixedCaseLettersSentenceWithDigits()
        {
            //Arrange
            string input = "i4 lo3Ve 2driNkiNg Te6A.";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo("I4 Lo3VE 2DrINKING TE6A."));
        }

        [Test, Order(17)]
        public void Test_CapitalizeSomeStringLetters_AllLowerCaseLettersSentenceWithSpecialSymbols()
        {
            //Arrange
            string input = "bl!ue is m@y fav)ori(te c$o^lo*r.";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo("BL!uE Is M@y FAv)orI(tE C$o^Lo*r."));
        }

        [Test, Order(18)]
        public void Test_CapitalizeSomeStringLetters_AllUpperCaseLettersSentenceWithSpecialSymbols()
        {
            //Arrange
            string input = "I) WE*NT S#HOP(PI@NG YE!ST-E^RD%&AY.";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo("I) WE*NT S#HOP(PI@NG YE!ST-E^RD%&AY."));
        }

        [Test, Order(19)]
        public void Test_CapitalizeSomeStringLetters_MixedCaseLettersSentenceWithSpecialSymbols()
        {
            //Arrange
            string input = "Ea*Ti$Ng fI^sh i(S VerY hE!aL@th>Y.";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo("EA*TI$NG FI^sH I(S VErY HE!AL@tH>Y."));
        }

        [Test, Order(20)]
        public void Test_CapitalizeSomeStringLetters_MixedAllLettersSentence()
        {
            //Arrange
            string input = "SAtU#rn4 i2s( a v-e3R&y la#R%g)e pLA+ne7T.";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo("SAtU#rn4 I2s( A v-E3R&y LA#R%G)E pLA+nE7T."));
        }

        [Test, Order(21)]
        public void Test_CapitalizeSomeStringLetters_AllDigits()
        {
            //Arrange
            string input = "4736067304";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo("4736067304"));
        }

        [Test, Order(21)]
        public void Test_CapitalizeSomeStringLetters_AllSpecialSymbols()
        {
            //Arrange
            string input = "*&(#$^)@!/<,}]";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo("*&(#$^)@!/<,}]"));
        }

        [Test, Order(21)]
        public void Test_CapitalizeSomeStringLetters_NoLetters()
        {
            //Arrange
            string input = "";

            //Act
            string output = StringLettersToUpper.CapitalizeSomeStringLetters(input);

            //Assert
            Assert.That(output, Is.EqualTo(""));
        }
    }
}